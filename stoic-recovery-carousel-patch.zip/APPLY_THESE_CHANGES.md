# Applying this patch to stoicsobriety

Drop these files into your local checkout at the **exact same relative paths**
they're in here (they overwrite the existing versions of `Book.php`,
`BookFactory.php`, `BookSeeder.php`, `Welcome.vue`, `Show.vue`, and
`catalog.ts` — the migration and `TestimonialCarousel.vue` are brand new).

```
app/Models/Book.php                                          (overwrite)
database/factories/BookFactory.php                            (overwrite)
database/migrations/2026_09_07_120000_add_testimonials_and_back_cover_to_books_table.php   (new)
database/seeders/BookSeeder.php                                (overwrite)
resources/js/components/TestimonialCarousel.vue                (new)
resources/js/pages/Welcome.vue                                 (overwrite)
resources/js/pages/books/Show.vue                               (overwrite)
resources/js/types/catalog.ts                                  (overwrite)
resources/seed-images/covers/architecture-of-surrender-front.jpg   (new)
resources/seed-images/covers/architecture-of-surrender-back.jpg    (new)
resources/seed-images/authors/quinn-stewart.jpg                (new)
```

## One thing to double-check first

I renamed your three `.webp` uploads to `.jpg` because `identify` showed
they're actually JPEG-encoded data, not real WebP — the `.webp` extension
was a mislabel, not a real conversion. If you'd rather keep them as
genuine WebP (smaller files), re-export them from wherever you made them
(Photoshop "Save As → WebP", or `cwebp front.jpg -o front.webp`) and update
the two `resource_path(...)` calls in `BookSeeder.php` accordingly. JPEG at
these sizes is fine for a book cover and author photo either way.

## Commands to run locally

```bash
# 1. Run the new migration
php artisan migrate

# 2. Make sure the public disk is symlinked (skip if you've already done this)
php artisan storage:link

# 3. Re-run the seeder — it's idempotent, safe to run again
php artisan db:seed --class=BookSeeder

# 4. Build frontend assets as usual (per your cheatsheet: build locally, commit public/build)
npm run build
```

After that, `php artisan serve` (or Herd/Valet) and check `/` — you should
see your book cover in the hero, your photo in the About the Author section,
and the new centered, auto-rotating testimonial carousel with placeholder
quotes at the bottom (dots + arrows under it). Visit the book's detail page
to see the back cover under the main cover/details grid.

## What to do next

- Replace the three placeholder entries in `BookSeeder.php`'s `testimonials`
  array with real reader quotes (`quote`, `author`, optional `context` like
  "Goodreads reviewer" or "Amazon review"), then re-run `db:seed`.
- The carousel auto-advances every 6 seconds by default (pauses on hover),
  with dots and prev/next arrows for manual control. Change the pace by
  passing `:interval-ms="8000"` (or whatever) to `<TestimonialCarousel>` in
  `Welcome.vue`.
- Per your cheat sheet: after `git push` to deploy, migrations run
  automatically via Deployer, but you'll still need to SSH in once to run
  `db:seed --class=BookSeeder` on the server the first time (seeders don't
  auto-run) and `storage:link` if it isn't already set up there.
